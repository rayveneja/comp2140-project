document.addEventListener('DOMContentLoaded', ()  => {
  const timeSlotSelect = document.getElementById('timeSlot');
  const bookingForm = document.getElementById('bookingForm');

  // Populate time slots dynamically
  const availableTimeSlots = ['8:00 AM', '1:30 PM', '4:30 PM']; 
  availableTimeSlots.forEach(slot => {
    const option = document.createElement('option');
    option.value = slot;
    option.text = slot;
    timeSlotSelect.add(option);
  
  });

  // Handle form submission
  bookingForm.addEventListener('submit', async (event) => {
    event.preventDefault(); 
    
    const formData = new FormData(bookingForm); 
    const data ={};
    formData.forEach((value, key) =>{
      data[key] = value;
    });

    try {
      const response = await fetch('http://localhost: 3000/book-event', 
        method: 'POST' ,
        headers: {
        'Content-Type' : 'application/json' ,
        },
        body: JSON. stringify(data),
      });

      if (response.ok) {
        alert('Booking successful! Confirmation email sent. ');
        bookingForm.reset();
      } else {
        const errorMessage = await response.text(); 
        alert ('Booking failed. ${errorMessage}'); 
      }
    } catch (error) {
      console.error('Error during booking:' , error);
      alert('An error occurred. Please try again later.');
    }

});


